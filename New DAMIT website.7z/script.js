//NAVIGACIJSKI MENI (če klikneš poleg, ti ga zapre)
const menu_checkbox = document.getElementById("menu_checkbox");
const menu_text = document.querySelectorAll(".menu ul li a button");
const header = document.getElementById("header");

function close_menu() {
  menu_checkbox.checked = false;
}
menu_text.forEach(function(item) {
  item.addEventListener("click",close_menu);
});
document.addEventListener("click",function(event) {
  if (!header.contains(event.target)) {
    close_menu();
  }
});